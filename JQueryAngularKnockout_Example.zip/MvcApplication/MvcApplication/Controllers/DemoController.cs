﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication.Models;

namespace MvcApplication.Controllers
{
    public class DemoController : Controller
    {
        //
        // GET: /Demo1/

        public ActionResult Index()
        {
            return View(new ResponseModel());
        }

        public ActionResult Index2()
        {
            return View(new ResponseModel());
        }

        public ActionResult Index3()
        {
            return View(new ResponseModel());
        }

        [HttpPost]
        public JsonResult GetStateAndUtilitiesByZip(string zipCode)
        {
            var result = new List<Utility>();
            if (zipCode.StartsWith("7"))
            {
                result.Add(
                    new Utility()
                    {
                        State = "TX", UdcCode = "ONCOR", UdcAccountNumberRegEx = "^TX\\d{3}$"
                    });
            }
            else
            {
                result.Add(new Utility() { State = "MD", UdcCode = "BGE", UdcAccountNumberRegEx = "^MD\\d{8}$" });
                result.Add(new Utility() { State = "MD", UdcCode = "PEPCO", UdcAccountNumberRegEx = "^\\d{10}$" });
            }
            return Json(result);
        }

        [HttpPost]
        public JsonResult GetPlans(string udcCode, string promoCode)
        {
            var result = new List<Plan>();
            result.Add(new Plan() { PlanId = 1001, PlanDescription = "Description for Plan " + 1001 });
            result.Add(new Plan() { PlanId = 1002, PlanDescription = "Description for Plan " + 1002 });
            result.Add(new Plan() { PlanId = 1002, PlanDescription = "Description for Plan " + 1003 });
            return Json(result);
        }

        public ActionResult Index4()
        {
            return View(new ResponseModel());
        }
    }

}
