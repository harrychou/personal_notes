﻿using System;

namespace MvcApplication.Models
{
    public class ResponseModel
    {
        public CallType CallType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }

        public string ZipCode { get; set; }
        public string AddressLine { get; set; }
        public string City { get; set; }
        public string State { get; set; }

        public string UdcCode { get; set; }
        public string UdcNumber { get; set; }

        public int PlanId { get; set; }
        public string PromoCode { get; set; }

        public string SpecialInstruction { get; set; }
        public bool IsSeniorCitizen { get; set; }
    }

    public class Utility
    {
        public string UdcCode { get; set; }
        public string State { get; set; }
        public string UdcAccountNumberRegEx { get; set; }
    }

    public class Plan
    {
        public int PlanId { get; set; }
        public string PlanDescription { get; set; }
    }

    public enum CallType
    {
        OutBound,
        InBound
    }
}